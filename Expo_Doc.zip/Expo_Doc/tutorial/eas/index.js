import redirect from '~/common/redirect';

export default redirect('/tutorial/eas/introduction/');
