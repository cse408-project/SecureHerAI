import redirect from '~/common/redirect';

export default redirect('/debugging/runtime-issues/');
