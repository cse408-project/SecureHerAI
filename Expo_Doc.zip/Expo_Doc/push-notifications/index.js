import redirect from '~/common/redirect';

export default redirect('/push-notifications/overview/');
