import redirect from '~/common/redirect';

export default redirect('/versions/latest/');
