import redirect from '~/common/redirect';

export default redirect('/develop/development-builds/introduction');
