import redirect from '~/common/redirect';

export default redirect('/regulatory-compliance/data-and-privacy-protection/');
