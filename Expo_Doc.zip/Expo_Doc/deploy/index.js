import redirect from '~/common/redirect';

export default redirect('/deploy/build-project/');
