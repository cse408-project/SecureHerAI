import redirect from '~/common/redirect';

export default redirect('/distribution/introduction');
